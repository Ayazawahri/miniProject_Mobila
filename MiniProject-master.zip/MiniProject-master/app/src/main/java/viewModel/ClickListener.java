package viewModel;

public interface ClickListener {
    void onAddButtonClicked(String name, String calories, String carbs, String fat, String protein);
}
